import pandas as pd

def ma_crossover_signal(df, fast=10, slow=30):
    df['ma_fast'] = df['close'].rolling(window=fast).mean()
    df['ma_slow'] = df['close'].rolling(window=slow).mean()

    if df['ma_fast'].iloc[-2] < df['ma_slow'].iloc[-2] and df['ma_fast'].iloc[-1] > df['ma_slow'].iloc[-1]:
        return 'buy'
    elif df['ma_fast'].iloc[-2] > df['ma_slow'].iloc[-2] and df['ma_fast'].iloc[-1] < df['ma_slow'].iloc[-1]:
        return 'sell'
    return None