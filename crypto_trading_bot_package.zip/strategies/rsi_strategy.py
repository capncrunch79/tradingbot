import pandas as pd

def rsi_signal(df, period=14, low=30, high=70):
    delta = df['close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)

    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    df['rsi'] = rsi

    if df['rsi'].iloc[-1] < low:
        return 'buy'
    elif df['rsi'].iloc[-1] > high:
        return 'sell'
    return None