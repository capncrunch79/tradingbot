from flask import Flask, render_template_string
import threading

app = Flask(__name__)
trade_log = []  # This will be populated in-memory by the trade engine

@app.route('/')
def home():
    return render_template_string('''
    <html>
        <head>
            <title>Crypto Trading Bot Dashboard</title>
            <meta http-equiv="refresh" content="10">
            <style>
                body { font-family: Arial; padding: 20px; }
                h1 { color: #4CAF50; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
            </style>
        </head>
        <body>
            <h1>Crypto Trading Bot Dashboard</h1>
            <h3>Live Trade Log</h3>
            <table>
                <tr><th>Action</th><th>Amount</th><th>Status</th></tr>
                {% for log in logs %}
                <tr><td>{{ log['action'] }}</td><td>{{ log['amount'] }}</td><td>{{ log['status'] }}</td></tr>
                {% endfor %}
            </table>
        </body>
    </html>
    ''', logs=trade_log)

def log_trade(action, amount, status):
    trade_log.append({'action': action, 'amount': amount, 'status': status})

def start_dashboard():
    threading.Thread(target=lambda: app.run(debug=False, use_reloader=False)).start()