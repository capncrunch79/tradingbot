import pandas as pd
from strategies.rsi_strategy import rsi_signal
from strategies.macd_strategy import macd_signal
from strategies.ma_crossover import ma_crossover_signal

class StrategyManager:
    def __init__(self):
        self.symbol = 'BTC/USDT'

    def evaluate_all(self, raw_ohlcv):
        df = pd.DataFrame(raw_ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')

        signals = {
            'rsi': rsi_signal(df),
            'macd': macd_signal(df),
            'ma_crossover': ma_crossover_signal(df),
        }

        votes = list(signals.values())
        if votes.count('buy') >= 2:
            return 'buy'
        elif votes.count('sell') >= 2:
            return 'sell'
        return None